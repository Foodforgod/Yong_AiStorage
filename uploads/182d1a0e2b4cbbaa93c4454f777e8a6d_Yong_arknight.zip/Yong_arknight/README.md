# 🛡️ Yong_arknight (Rhodes Island HR Management)

A web-based Arknights operator gallery and personnel database system built with PHP, PDO, and MySQL, featuring dynamic phase promotion toggles, attribute tracking, combat skills configurations, and image zooming.

---

## ✨ Key Features

* **Operator Gallery & Search**: Browse all recruited operators, filter by class (Vanguard, Guard, Sniper, Defender, Medic, Caster, Supporter, Specialist), or search by name.
* **Phase Promotion Toggling**: Switch between Phase 0/1 and Elite 2 stats and portraits dynamically on an operator's dossier page.
* **Dynamic Image Management**: Upload and store operator portraits and Elite 2 art files directly into local database directories.
* **Interactive Image Zooming**: Zoom in/out via mouse wheel or click-to-zoom on operator portraits.
* **Recruitment & Modification**: Add new operators or update existing dossiers, including combat skills (up to 3 skills), base/Elite 2 attributes, and lore/archive data.
* **Dismissal System**: Safely remove operator files from the database archive with confirmation prompts.

---

## 📂 System File Directory

| Path / File | Description |
| :--- | :--- |
| **index.php** | Main operator gallery dashboard with search, filtering, and rarity cards. |
| **add.php** | Recruitment form page with file upload fields to add new operators into the database. |
| **details.php** | Detailed operator dossier with attribute tables, skill lists, and Phase 0/E2 switcher. |
| **edit.php** | Data modification form to update operator attributes, skills, and image paths. |
| **delete.php** | Backend handler to safely remove/dismiss an operator record. |
| **db.php** | Secure PDO database connection configuration file. |
| **uploads/** | Local server directory folder storing uploaded operator portrait and Elite 2 art files. |
| **style.css** | Custom dark-themed Arknights UI stylesheet with grid galleries and animations. |

---

## 🛠️ Tech Stack

* **Backend**: PHP 8+ (with secure PDO database operations and file upload handlers)
* **Database**: MySQL / MariaDB (arknights_db with text paths for images)
* **Frontend**: HTML5, CSS3 (Flexbox/Grid), and JavaScript

---

## ⚙️ Step-by-Step Guide: How to Use This Project

### Step 1: Local Environment Setup
<img width="1912" height="990" alt="Screenshot 2026-08-24 150922" src="https://github.com/user-attachments/assets/a7441093-69cd-4ab7-ad26-42df2354d7cd" />
1. Clone or place your repository inside your local server directory (such as XAMPP's htdocs folder).
<img width="1917" height="1086" alt="image" src="https://github.com/user-attachments/assets/6cf5215d-84fd-4a90-ad0a-f729e581e94b" />
2. Start Apache and MySQL services via your XAMPP control panel.

### Step 2: Set Up the Database & Folders
<img width="1916" height="1086" alt="image" src="https://github.com/user-attachments/assets/01cace2a-7ecb-4323-a512-d665fe8a9a6c" />
1. Open your browser and go to phpMyAdmin (http://localhost/phpmyadmin/).

<img width="1917" height="1027" alt="image" src="https://github.com/user-attachments/assets/fe58e75c-4459-4817-9a68-aefb6f6e6db0" />

2. Create a new database named **arknights_db**.

<img width="1602" height="478" alt="image" src="https://github.com/user-attachments/assets/90223d3e-8de0-45a8-8353-9f8a5d373b39" />

3. Import the provided SQL dump or create the `operators` table with text columns for image paths.

<img width="860" height="45" alt="image" src="https://github.com/user-attachments/assets/23d4de9f-775c-4f0b-b494-c86aa8ccc9d5" />

4. Create a folder named **uploads** inside your project root directory (`C:\xampp\htdocs\Yong_arknight\uploads\`) to properly store uploaded image files.

### Step 3: Accessing the Gallery
<img width="1916" height="1093" alt="image" src="https://github.com/user-attachments/assets/dbf3a8f1-2735-4855-8ed7-bdf375455ade" />

1. Open your web browser and navigate to the project root directory:
   http://localhost/Yong_arknight/index.php

2. You will see the main **Rhodes Island Archives** gallery showcasing cards color-coded by rarity with E2 indicator tags.

### Step 4: Searching and Filtering Operators
<img width="1916" height="957" alt="image" src="https://github.com/user-attachments/assets/7b0b3d0a-1a6b-4eaa-b041-3688ae88e468" />

1. Use the search bar at the top of the gallery to look up operators by their name.
2. Select a specific class from the dropdown menu (e.g., GUARD, SNIPER, MEDIC) to filter results.
3. Click **RESET** to clear filters and view all operators.

### Step 5: Viewing and Interacting with Operator Dossiers
<img width="1917" height="977" alt="image" src="https://github.com/user-attachments/assets/caaf7a25-26cd-4173-a2e9-2af5e41f7ea3" />

1. Click on any operator card in the gallery to open their detailed dossier page (details.php).
2. Use the **PROMOTION** toggle buttons to switch between **PHASE 0/1** and **PHASE 2** stats/portraits.
3. Scroll over the operator portrait and use your mouse wheel or click to zoom in/out of the artwork.
4. Review combat skill details, icons, and archive background lore.

### Step 6: Recruiting New Operators (with Images)
<img width="1890" height="965" alt="image" src="https://github.com/user-attachments/assets/d4fc0a49-7205-4bf3-ae53-490b942fdea7" />

1. Click the **+ RECRUIT OPERATOR** button on the top right of the main gallery (index.php).
2. Fill out the Core Profile (Name, Rarity, Class) in add.php.
3. Select and upload your image files for both the **Base Portrait** and optional **Elite 2 Portrait**.
4. Click **Confirm Recruitment** to save the file paths to the database and upload the images into the `uploads/` directory.

### Step 7: Modifying or Dismissing Operator Records
<img width="1906" height="967" alt="image" src="https://github.com/user-attachments/assets/2386fc47-7ace-4854-9054-7eb375404a18" />

* **Modify Data**: While viewing an operator's dossier (details.php), click the **MODIFY DATA** button to edit existing stats, skills, or update image files in edit.php.

<img width="317" height="93" alt="image" src="https://github.com/user-attachments/assets/11f5a0dc-98e8-4e80-a80b-229e5d3bf8ab" />

* **Dismiss Operator**: Click the **[ DISMISS OPERATOR ]** link at the bottom of any operator card in the gallery to permanently remove them from the records with a confirmation check.

---

## 📄 License

This project is open-source and available under the MIT License.
